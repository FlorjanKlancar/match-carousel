declare module "*.jpg";
